representation
==============


.. toctree::
    :maxdepth: 2

.. rubric:: Classes

.. autosummary::
    :nosignatures:
    :toctree: ./
    :template: class.rst

    hail.representation.Variant
    hail.representation.AltAllele
    hail.representation.Genotype
    hail.representation.Locus
    hail.representation.Interval
    hail.representation.Struct
