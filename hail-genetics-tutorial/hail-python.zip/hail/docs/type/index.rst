type
====


.. toctree::
    :maxdepth: 2

.. rubric:: Classes

.. autosummary::
    :nosignatures:
    :toctree: ./
    :template: class.rst

    hail.type.Type
    hail.type.TString
    hail.type.TInt
    hail.type.TLong
    hail.type.TFloat
    hail.type.TDouble
    hail.type.TBoolean
    hail.type.TArray
    hail.type.TSet
    hail.type.TDict
    hail.type.TVariant
    hail.type.TGenotype
    hail.type.TAltAllele
    hail.type.TLocus
    hail.type.TInterval
    hail.type.TStruct
    hail.type.Field
